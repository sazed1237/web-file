<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Sazed Creations</title>
</head>
<body>
    <div class="one">
    welcome

    <h1>Sazed Creations</h1>

        <?php
            echo 'This is my first project in PHP!';

        ?>
    </div>

    <div class="sidebar">
        <p>IIST</p>
    </div>

    <div class="tree">
    <?php
    $num1=22;
    $num2='84';
    $num3=89;
    $num4=754;
    $num5=456;
    $result= $num1 + $num2;
    $result1 = $num2 * $num4;
   
    

    echo 'Multiplications = '.$result;
    if($num1===$num2){
        echo '<br> true';
    }else{
        echo '<br> false <br>';
    }
    var_dump($num2);

    print_r($result1);
    
    ?>

<?php
$t = date("H");


if ($t < "20") {
  echo " <br> Have a good day!";
}else
    echo "<br> Have a Sweet Dream!";
?>
    </div>
</body>
</html>